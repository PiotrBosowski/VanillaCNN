#include "VectorToMatrix.h"
#include <iostream>

void VectorToMatrix::connect(Layer& first, Layer& second)
{
	std::cout << "connecting vector to matrix" << std::endl;
}
